//
//  PaymentView.swift
//  LowPrice
//
//  Created by bsmah Ali on 26/08/1444 AH.
//

import SwiftUI

struct PaymentView: View {
    @State private var Discount: String = ""
    
    var body: some View {
        Form{
            Section{
                HStack{
                    Text("Subtotal")
                    Spacer()
                    Text("30 SAR")
                }
                HStack{
                    Text("Delivery")
                    Spacer()
                    Text("30 SAR")
                }
                HStack{
                    Text("Taxes")
                    Spacer()
                    Text("3 SAR")
                }
                HStack{
                    Text("Total")
                        .font(.title)
                    Spacer()
                    Text("63 SAR")
                        .font(.title)
                    
                }
            }.padding(.top,20)
            Section{
                HStack{
                    Label("Check Out", systemImage: "creditcard").foregroundColor(Color.black)
                    Spacer()
                    Button{}
                label:{Image(systemName: "chevron.right")
                        .renderingMode(.template)
                        .foregroundColor(Color.black)
                    .padding(.trailing, 0.0)}
               
                }}.padding(.top,20)
        }.padding(.top,100)
    }}
struct PaymentView_Previews: PreviewProvider {
    static var previews: some View {
        PaymentView()
    }
}
