//
//  BasketView.swift
//  LowPrice
//
//  Created by bsmah Ali on 22/08/1444 AH.
//

import SwiftUI

struct BasketView: View {
    var body: some View {
        VStack{
            
            Text("Empty cart")
                .font(.title)
                .fontWeight(.bold)
      
            
        
    }
}
}
struct BasketView_Previews: PreviewProvider {
    static var previews: some View {
        BasketView()
    }
}
