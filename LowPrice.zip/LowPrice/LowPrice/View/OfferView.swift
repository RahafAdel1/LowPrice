//
//  OfferView.swift
//  LowPrice
//
//  Created by bsmah Ali on 22/08/1444 AH.
//

import SwiftUI

struct OfferView: View {
    @State var searchTerm = ""

    var columnGrid: [GridItem] = [GridItem(.flexible(),spacing: 5),GridItem(.flexible(),spacing: 5)]
    
    struct Product_offer {
        var images : Image
        var name : String
        var detail : String
        var price : String
        var n_price : String
        
    }
    
    var offer_p: [Product_offer] = [
        
        Product_offer(images:Image("Pepsi"), name: "Pepsi",detail: "per one can", price:"1.75 SAR", n_price: "1 SAR"),
        Product_offer(images:Image("Toast"), name: "Toast",detail: "per 500g", price:"6.50 SAR", n_price: "4 SAR"),
        Product_offer(images:Image("Eggs"), name: "Eggs",detail: "per 15 pices", price:"13.25 SAR", n_price: "10 SAR"),
        Product_offer(images:Image("Orange"), name: "Orange",detail: "per 1Kg", price:"10.50 SAR", n_price: "6.25 SAR"),
        Product_offer(images:Image("Str"), name: "Strawberry",detail: "per 500g", price:"26 SAR", n_price: "14 SAR"),
        Product_offer(images:Image("QuinoaPasta"), name: "Pasta",detail: "per 500g", price:"12 SAR", n_price: "6.75 SAR"),
        Product_offer(images:Image("eggPasta"), name: "Pasta",detail: "per 1 pice", price:"13 SAR", n_price: "8 SAR"),
        Product_offer(images:Image("Apples"), name: "Apple",detail: "per 500g", price:"10.50 SAR", n_price: "5 SAR")
    ]
    var body: some View {
           
        NavigationView{
                   
                   ScrollView {
                       
                       Image(systemName:"slider.horizontal.3")
                           .resizable()
                           .foregroundColor(Color("greenish"))
                           .frame(width:30, height: 30)
                           .padding(.trailing, 300)
                           .navigationBarTitle("Offer", displayMode: .inline)
                           .searchable(text: $searchTerm){}
                              
                       LazyVGrid(columns: columnGrid, spacing: 20){
                            ForEach(0..<offer_p.count) { index in
                                ZStack{
                                    RoundedRectangle(cornerRadius:  20).stroke(Color("greenish"), lineWidth:3).frame(width:155 , height:170)
                                    VStack{
                                        (offer_p[index].images).resizable().frame(width: 155, height: 100).cornerRadius(20).shadow(radius: 5)
                                        
                                        Text(offer_p[index].name)
                                            .foregroundColor(Color("greenish"))
                                            .multilineTextAlignment(.leading)
                                            .padding(.leading, -60.0)
                                        
                                        Text(offer_p[index].detail).font(.caption2)
                                            .fontWeight(.light)
                                            .foregroundColor(Color("greenish"))
                                            .multilineTextAlignment(.leading)
                                            .padding(.leading, -50.0)
                                        HStack(){
                                            Text(offer_p[index].price).underline().font(.caption2)
                                                .fontWeight(.light)
                                                .foregroundColor(Color.black)
                                                .multilineTextAlignment(.leading)
                                                .padding(.leading, -7.0)
                                            Text(offer_p[index].n_price).font(.caption2)
                                                .fontWeight(.light)
                                                .foregroundColor(Color.red)
                                                .multilineTextAlignment(.leading)
                                            Button{}
                                        label:{Image(systemName: "cart.badge.plus")
                                                .foregroundColor(Color("greenish"))
                                            .padding(.trailing, 0.0)}
                                        }
                                    }
                                    
                                }
                                
                            }
                       }
                   }
                }
    }
    }

    struct OfferView_Previews: PreviewProvider {
        static var previews: some View {
            OfferView()
        }
    }




        

    

    
    
