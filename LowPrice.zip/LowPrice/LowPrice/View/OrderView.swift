//
//  OrderView.swift
//  LowPrice
//
//  Created by bsmah Ali on 26/08/1444 AH.
//

import SwiftUI


struct OrderView: View {
    var total = 30
    
    struct orderV : Identifiable {
        let id = UUID()
        let imges : String
        let name : String
        let price: Int
        @State var amount : Int
        let curreency: String
        let m_image: String
        
    }
    static let items2 : [orderV] = [
        orderV(imges:"Str", name: "Strawberry", price: 15, amount : 0, curreency: "SAR", m_image: "Tastyfood"),
        orderV(imges:"Banana", name: "Banana", price: 6,amount : 0, curreency: "SAR", m_image: "Tastyfood"),
        orderV(imges: "KelpNoodles", name: "Kelp Noodles", price: 9,amount : 0, curreency: "SAR", m_image: "yum market")
    ]
    
    var body: some View {
        NavigationView{
            VStack {
                HStack{
                    Text("(3 items)")
                    Spacer()
                    Button{}label: {
                        Text("Empty")
                            .foregroundColor(Color.black)
                        Image(systemName: "trash")
                        .foregroundColor(Color("greenish"))}}
                Divider()
                ForEach(OrderView.items2, id: \.id) { item in
                    HStack{
                        Image(item.imges)
                            .resizable()
                            .frame(width: 80, height: 80)
                        VStack{
                            Text(item.name)
                                .foregroundColor(Color("greenish"))
                            
                            HStack{
                                Text("\(item.price)")
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("greenish"))
                                Text(item.curreency).fontWeight(.bold) .foregroundColor(Color("greenish"))
                            }
                        }
                        Spacer()
                        /*   Stepper("\( orderV.name): \( orderV.amount)", value: orderV.$amount)*/
                        Image(item.m_image)
                            .resizable()
                            .frame(width: 30, height: 30)
                    }
                    .padding()
                }
                Divider()
                HStack{
                    Text("total = \(total)")
                        .font(.title2)
                    Text("SAR")
                        .font(.title2)
                    
                    NavigationLink(
                        destination:PaymentView()){
                            Text("Collect & Delivery")
                                .font(.title2)
                                .foregroundColor(Color.white)
                                .frame(width: 100.0, height: 50.0)
                                .background(Color("greenish"))
                        }
                    
                    
                    
                    /* }label:{
                     Text("Collect & Delivery")
                     .font(.title2)
                     .fontWeight(.bold)8*/
                    
                    
                }
                
            }
            .navigationBarTitle("order",displayMode: .inline)
            .padding()
        }
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView()
    }
}
