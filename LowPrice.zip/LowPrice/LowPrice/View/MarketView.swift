//
//  HomeView.swift
//  LowPrice
//
//  Created by bsmah Ali on 22/08/1444 AH.
//

import SwiftUI

struct MarketView: View {
    @State var searchTerm = ""

    var body: some View {
        NavigationStack {
            ZStack {
                ScrollView() {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Hello, ..")
                            .font(.title).bold()
                            .foregroundColor(.black)
                            .multilineTextAlignment(.leading)
                            .padding(EdgeInsets(top: 0, leading: 5, bottom: 0, trailing: 10))
                        HStack(spacing: 2) {
                            Image(systemName: "mappin.and.ellipse")
                            Text("Saudi Arabia, Riyadh 12211")
                                .foregroundColor(.accentColor)
                        }.padding(EdgeInsets(top: 0, leading: 15, bottom: 0, trailing: 10))
                        
                        ProductCarousel(products: [Product(id: 1, title: "", image: "image1"),
                        Product(id: 2, title: "", image: "Offer_M"),
                        Product(id: 3, title: "", image: "Ramadan")]).padding(EdgeInsets(top: -20, leading: 0, bottom: -20, trailing: 0))
                        
                        Text("Category").font(.title3).fontWeight(.bold).foregroundColor(Color("greenish")).padding(15)
                        
                        
                        
                        VStack {
                                HStack {
                                    
                                    NavigationLink(destination: CategoryView()){
                                        Group{
                                            CategoryCardView(cardImage: Image("Fruits"), title: "Fruits")
                                        }
                                    }

                                
                                    Button{}
                                label:{CategoryCardView(cardImage: Image("Bakery"), title: "Bakery")
                                }
                                    Button{}
                                label:{
                                    CategoryCardView(cardImage: Image("Vigtables"), title: "Vigtables")
                                }
                                                   }
                                                   
                                HStack {
                                    Button{}
                                label:{ CategoryCardView(cardImage: Image("Snacks"), title: "Snacks")
                                }
                                    Button{}
                                label:{  CategoryCardView(cardImage: Image("Drink"), title: "Drink")
                                }
                                    Button{}
                                label:{ CategoryCardView(cardImage: Image("Meat"), title: "Meat and poultry")
                                }
                                                   }
                                               }.padding(2)
                                           }.background(Color.white)
                                       }.background(Color.clear)
                                   }.navigationBarTitleDisplayMode(.large)
                                       .navigationBarItems(
                                           leading:
                                LeadingBarItem()
                                       )
                               }.searchable(text: $searchTerm,placement: .navigationBarDrawer(displayMode: .always))
                           }
                       }
                           
                          


    
    
    struct MarketView_Previews: PreviewProvider {
        static var previews: some View {
            MarketView()
            
        }
    }

