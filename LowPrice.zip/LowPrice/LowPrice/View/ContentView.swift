//
//  ContentView.swift
//  LowPrice
//
//  Created by bsmah Ali on 22/08/1444 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
      TabBar()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
