//
//  TabBar.swift
//  LowPrice
//
//  Created by bsmah Ali on 25/08/1444 AH.
//

import SwiftUI

struct TabBar: View {
    
    var body: some View {
        TabView {
            MarketView()
                .tabItem{
                    
                    Label("Market", systemImage: "takeoutbag.and.cup.and.straw")
                    
                }
            OrderView().tabItem{
                Label("cart", systemImage:"cart")
                
            }
            AccountView().tabItem{
                Label("Account", systemImage: "person")
              
            }
        }.accentColor(Color("greenish"))
    }
}
struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar()
    }
}
