//
//  ProductCarouselCard.swift
//  LowPrice
//
//  Created by bsmah Ali on 27/08/1444 AH.
//

import SwiftUI

struct ProductCarouselCard: View {
    let product: Product
    var body: some View {
        ZStack{
            HStack {
                VStack(alignment: .leading) {
                    VStack {
                        Image("\(product.image)")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .cornerRadius(20)
                    }.padding(20)
                }.foregroundColor(.white)
                Spacer()
            }
        }.frame(height: 200)
        .shadow(color: .gray.opacity(0.1), radius: 4, x: 1, y: 2)
    }
}

struct ProductCarouselCard_Previews: PreviewProvider {
    static var previews: some View {
        ProductCarouselCard(product: Product.sampleProducts[0])
    }
}
