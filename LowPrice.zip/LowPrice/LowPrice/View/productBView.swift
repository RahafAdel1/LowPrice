//
//  productBView.swift
//  LowPrice
//
//  Created by bsmah Ali on 28/08/1444 AH.
//

import SwiftUI

struct productBView: View {
    var columnGrid: [GridItem] = [GridItem(.flexible(),spacing: 5),GridItem(.flexible(),spacing: 5)]
    
    struct Product_d {
        var images : Image
        var market : Image
        var detail : String
        var price : String
    }
    
    var B_details: [Product_d] = [
        Product_d(images:Image("Banana"), market: Image("Tastyfood"), detail: "Per 500g", price:"16.5 SAR"),
        Product_d(images:Image("Banana"), market: Image("willcha"), detail: "Per 500g",price:"20 SAR"),
        Product_d(images:Image("Banana"), market: Image("yum market"), detail: "Per 500g", price:"14 SAR"),
        Product_d(images:Image("Banana"), market: Image("Survey"), detail: "Per 500g", price:"17.25 SAR")
    ]
    var body: some View {
        NavigationView{
            ScrollView {
                Image(systemName:"slider.horizontal.3")
                    .resizable()
                    .foregroundColor(Color("greenish"))
                    .frame(width:30, height: 30)
                    .padding(.trailing, 300)
                    .navigationBarTitle("Details", displayMode: .inline)
                LazyVGrid(columns: columnGrid, spacing: 20){
                    ForEach(0..<B_details.count) { index in
                        
                        ZStack{
                            RoundedRectangle(cornerRadius:20).stroke(Color("greenish"), lineWidth:3).frame(width:180 , height:200)
                            VStack{
                                (B_details[index].images).resizable().frame(width: 165, height: 100).cornerRadius(20).shadow(radius: 5)
                                HStack{
                                    (B_details[index].market).resizable().frame(width: 35, height: 35).cornerRadius(20).shadow(radius: 5)
                                    
                                    Text(B_details[index].detail).font(.caption2)
                                        .fontWeight(.regular)
                                    .foregroundColor(Color("greenish"))}
                                .padding(.trailing, 51.0)
                                HStack(){
                                    Text(B_details[index].price).font(.caption2)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color("greenish"))
                                        .multilineTextAlignment(.leading)
                                    Button{}
                                label:{Image(systemName: "cart.badge.plus")
                                        .foregroundColor(Color("greenish"))
                                    .padding(.trailing, 0.0)} } }
                            .padding(.trailing, 0.0)
                        }.padding(.top,25) } }
                
            }
        }
    }
}
struct productBView_Previews: PreviewProvider {
    static var previews: some View {
        productBView()
    }
}
