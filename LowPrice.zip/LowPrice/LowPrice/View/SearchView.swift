//
//  SearchView.swift
//  LowPrice
//
//  Created by bsmah Ali on 26/08/1444 AH.
//

import SwiftUI

struct SearchView: View {
    @Binding var searchTerm : String
    
    var columnGrid: [GridItem] = [GridItem(.flexible(),spacing: 1), GridItem(.flexible(),spacing: 1)]
    
    struct s_Product {
        var images : Image
        var name : String
        var range : String
        
    }
    
    var search_R_C: [s_Product] = [
        s_Product(images:Image("AlmondChoclate"), name: "AlmondChoclate",range:"10 ~ 16 SAR "),
        s_Product(images:Image("Cramela"), name: "Caremla Choclate",range:"11 ~ 18 SAR "),
        s_Product(images:Image("DarkChoclate"), name: "Dark Choclate",range:"10 ~ 15 SAR "),
        s_Product(images:Image("PBCups"), name: "Peanut butter Cups",range:"20 ~ 27 SAR "),
        s_Product(images:Image("SilkVelvet"), name: "Silk Velvet Choclate",range:"8 ~ 12 SAR "),
        s_Product(images:Image("SeaSalt"), name: "Sea Salt Choclate",range:"15 ~ 24 SAR ")
    ]
    
    var search_R_P: [s_Product] = [
        s_Product(images:Image("QuinoaPasta"), name: "Quinoa Pasta",range:"20 ~ 25 SAR "),
        s_Product(images:Image("KelpNoodles"), name: "Kelp Noodles",range:"22 ~ 27 SAR "),
        s_Product(images:Image("GFPasta"), name: "Glutten Free Pasta",range:"15 ~ 21 SAR "),
        s_Product(images:Image("eggPasta"), name: "egg Pasta",range:"14 ~ 18 SAR "),
        s_Product(images:Image("CheddarPasta"), name: "Cheddar Pasta",range:"15 ~ 17 SAR ")]
    
    var body: some View {
        VStack{
            NavigationView{
                ScrollView {
                    HStack(){
                        Text(searchTerm)
                            .font(.title3)
                            .foregroundColor(Color("greenish"))
                            .padding(.leading, 20.0)
                        Spacer()
                        Image(systemName:"slider.horizontal.3")
                            .resizable()
                            .foregroundColor(Color("greenish"))
                            .padding(.trailing, 18.0)
                            .frame(width:50, height: 30)
                        
                    }.padding(.top, 30.0).navigationBarTitle("Search", displayMode: .inline)
                    
                    Divider()
                    LazyVGrid(columns: columnGrid, spacing: 10){
                        ForEach(0..<search_R_C.count) { index in
                            ZStack{
                                RoundedRectangle(cornerRadius:  20).stroke(Color("greenish"), lineWidth:3).frame(width:170 , height:200)
                                VStack{
                                    (search_R_C[index].images).resizable().frame(width: 100, height: 100).cornerRadius(20)
                                    
                                    Text(search_R_C[index].name)
                                        .font(.headline)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color("greenish"))
                                        .multilineTextAlignment(.leading)
                                        .padding(.bottom, 4.0)
                                    
                                    HStack(){
                                        Text(search_R_C[index].range).font(.body)
                                            .fontWeight(.regular)
                                            .foregroundColor(Color("greenish"))
                                            .padding(.trailing, 20.0)
                                        
                                        
                                        Button {
                                            print("More details!")
                                        } label: {
                                            Image(systemName: "arrow.up.forward.app.fill")
                                                .foregroundColor(Color("greenish"))
                                            .padding(.trailing, 1.0)} } } } } }.padding(.top, 30.0)
                }}}}}
              
                                        
                                        
        struct SearchView_Previews: PreviewProvider {
            static var previews: some View {
                SearchView(searchTerm: .constant(""))
            }
        }
        
    
