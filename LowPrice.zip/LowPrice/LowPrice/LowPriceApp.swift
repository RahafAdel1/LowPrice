//
//  LowPriceApp.swift
//  LowPrice
//
//  Created by bsmah Ali on 22/08/1444 AH.
//

import SwiftUI

@main
struct LowPriceApp: App {
    
    var body: some Scene {
        WindowGroup {
            NavigationView(){
                TabBar()
                
            }
        }
    }
}
